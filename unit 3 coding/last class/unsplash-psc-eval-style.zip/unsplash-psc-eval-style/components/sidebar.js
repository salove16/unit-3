function sidebar(){
    return`<div>menu</div>
    <div>login</div>
    <div>signup</div>
    <input type="text" name="" id="search">
    <div>news</div>
    <div>api</div>`;

}

export default sidebar;