// const key="G0VS2ZyPPAT2htSW4rP-OBc__gO6aIU2k83kEm9Kf14"


async function makeapicall(url) {

try {
    let res = await fetch(url)
    let data = await res.json()
    return data
} catch (error) 
{
    console.log("error:",error)
}
   
}


function appendimage(data,parent){
    data.forEach(el => {
        
    let div=document.createElement("div")

    let image=document.createElement("img")
    image.src=el.urls.small

    let h4=document.createElement("h4")
    h4.textContent=el.user.name
    div.append(image,h4)
    // document.getElementById("main").append(div)
parent.append(div)

 });

}


export  { makeapicall , appendimage } ;